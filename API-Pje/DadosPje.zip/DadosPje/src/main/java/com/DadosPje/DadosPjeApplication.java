package com.DadosPje;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class DadosPjeApplication {

	public static void main(String[] args) {
		SpringApplication.run(DadosPjeApplication.class, args);
	}

}
