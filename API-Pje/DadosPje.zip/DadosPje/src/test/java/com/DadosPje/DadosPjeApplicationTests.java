package com.DadosPje;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DadosPjeApplicationTests {

	@Test
	void contextLoads() {
	}

}
